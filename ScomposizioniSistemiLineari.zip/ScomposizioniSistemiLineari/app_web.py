import math
import matplotlib.pyplot as plt
import numpy as np
import streamlit as st
import sympy as sp

st.set_page_config(
    page_title="App Matematica Interattiva", layout="centered"
)

st.title("🧮 Calcolatore di Matematica Interattivo")

categoria = st.sidebar.radio(
    "Seleziona Categoria", ["Scomposizioni", "Sistemi Lineari"]
)

# ==========================================================
# 1. SCOMPOSIZIONI
# ==========================================================
if categoria == "Scomposizioni":
  st.header("Scomposizione di Polinomi")

  opzione = st.selectbox(
      "Scegli il tipo di scomposizione:",
      [
          "1. Raccoglimento totale",
          "2. Raccoglimento parziale",
          "3. Differenza di due quadrati",
          "4. Differenza di cubi",
          "5. Somma di cubi",
          "6. Quadrato di binomio",
          "7. Trinomio notevole (a = 1)",
          "8. Trinomio notevole (a ≠ 1)",
          "9. Cubo di binomio",
          "10. Quadrato di un trinomio",
          "11. Cubo di un trinomio",
      ],
  )

  # --- 1. Raccoglimento totale ---
  if opzione == "1. Raccoglimento totale":
    st.subheader("Raccoglimento Totale [ab + ac = a(b + c)]")
    a = st.number_input("Primo coefficiente (es. 6)", value=6, step=1)
    b = st.number_input("Secondo coefficiente (es. 9)", value=9, step=1)

    if st.button("Calcola e mostra procedimento"):
      mcd = math.gcd(int(a), int(b))
      r1 = int(a) // mcd
      r2 = int(b) // mcd
      st.write("### 📝 Procedimento:")
      st.write(f"1. Troviamo il MCD tra {int(a)} e {int(b)}, che è **{mcd}**.")
      st.write(
          f"2. Dividiamo entrambi i coefficienti per {mcd}: {int(a)}/{mcd} ="
          f" {r1}, {int(b)}/{mcd} = {r2}."
      )
      st.success(
          f"**Risultato:** {int(a)}x + {int(b)}y = **{mcd}({r1}x + {r2}y)**"
      )

  # --- 2. Raccoglimento parziale ---
  elif opzione == "2. Raccoglimento parziale":
    st.subheader(
        "Raccoglimento Parziale [ax + ay + bx + by = (a + b)(x + y)]"
    )
    a_val = st.text_input("Primo fattore comune 'a'", value="a")
    b_val = st.text_input("Secondo fattore comune 'b'", value="b")
    x_val = st.text_input("Prima variabile 'x'", value="x")
    y_val = st.text_input("Seconda variabile 'y'", value="y")

    if st.button("Calcola e mostra procedimento"):
      st.write("### 📝 Procedimento:")
      st.write(
          f"1. Raccogliamo **{a_val}** dai primi due termini e **{b_val}** dagli"
          " ultimi due:"
      )
      st.write(
          f"$$\\Rightarrow {a_val}({x_val} + {y_val}) + {b_val}({x_val} +"
          f" {y_val})$$"
      )
      st.write(f"2. Raccogliamo il fattore comune **({x_val} + {y_val})**.")
      st.success(
          f"**Risultato:** **({a_val} + {b_val})({x_val} + {y_val})**"
      )

  # --- 3. Differenza di quadrati ---
  elif opzione == "3. Differenza di due quadrati":
    st.subheader("Differenza di Due Quadrati [a² - b² = (a - b)(a + b)]")
    a2 = st.number_input(
        "Primo termine al quadrato (a²)", value=16.0, min_value=0.0
    )
    b2 = st.number_input(
        "Secondo termine al quadrato (b²)", value=9.0, min_value=0.0
    )

    if st.button("Calcola e mostra procedimento"):
      a_root = math.sqrt(a2)
      b_root = math.sqrt(b2)
      st.write("### 📝 Procedimento:")
      st.write(f"1. Calcoliamo \(\\sqrt{{{a2}}} = {a_root:g}\).")
      st.write(f"2. Calcoliamo \(\\sqrt{{{b2}}} = {b_root:g}\).")
      st.success(
          f"**Risultato:** {a2:g}x² - {b2:g} = **({a_root:g}x -"
          f" {b_root:g})({a_root:g}x + {b_root:g})**"
      )

  # --- 4. Differenza di cubi ---
  elif opzione == "4. Differenza di cubi":
    st.subheader("Differenza di Cubi [a³ - b³ = (a - b)(a² + ab + b²)]")
    a3 = st.number_input("Primo termine al cubo (a³)", value=27.0)
    b3 = st.number_input("Secondo termine al cubo (b³)", value=8.0)

    if st.button("Calcola e mostra procedimento"):
      a_val = round(a3 ** (1 / 3), 4)
      b_val = round(b3 ** (1 / 3), 4)
      st.write("### 📝 Procedimento:")
      st.write(f"1. Radice cubica di {a3}: \(a = {a_val:g}\).")
      st.write(f"2. Radice cubica di {b3}: \(b = {b_val:g}\).")
      st.write(
          f"3. Falso quadrato: $a^2 + ab + b^2 = {a_val**2:g}x^2 +"
          f" {a_val*b_val:g}x + {b_val**2:g}$."
      )
      st.success(
          f"**Risultato:** {a3:g}x³ - {b3:g} = **({a_val:g}x -"
          f" {b_val:g})({a_val**2:g}x² + {a_val*b_val:g}x + {b_val**2:g})**"
      )

  # --- 5. Somma di cubi ---
  elif opzione == "5. Somma di cubi":
    st.subheader("Somma di Cubi [a³ + b³ = (a + b)(a² - ab + b²)]")
    a3 = st.number_input("Primo termine al cubo (a³)", value=1.0)
    b3 = st.number_input("Secondo termine al cubo (b³)", value=27.0)

    if st.button("Calcola e mostra procedimento"):
      a_val = round(a3 ** (1 / 3), 4)
      b_val = round(b3 ** (1 / 3), 4)
      st.write("### 📝 Procedimento:")
      st.write(f"1. Radice cubica di {a3}: \(a = {a_val:g}\).")
      st.write(f"2. Radice cubica di {b3}: \(b = {b_val:g}\).")
      st.write(
          f"3. Falso quadrato: $a^2 - ab + b^2 = {a_val**2:g}x^2 -"
          f" {a_val*b_val:g}x + {b_val**2:g}$."
      )
      st.success(
          f"**Risultato:** {a3:g}x³ + {b3:g} = **({a_val:g}x +"
          f" {b_val:g})({a_val**2:g}x² - {a_val*b_val:g}x + {b_val**2:g})**"
      )

  # --- 6. Quadrato di binomio ---
  elif opzione == "6. Quadrato di binomio":
    st.subheader("Quadrato di Binomio [a²x² ± 2abx + b² = (ax ± b)²]")
    a = st.number_input("Coefficiente di x² (a²)", value=4.0, min_value=0.0)
    b = st.number_input("Coefficiente di x (±2ab)", value=12.0)
    c = st.number_input("Termine noto (b²)", value=9.0, min_value=0.0)

    if st.button("Calcola e mostra procedimento"):
      sq_a = math.sqrt(a)
      sq_c = math.sqrt(c)
      segno = "+" if b >= 0 else "-"
      st.write("### 📝 Procedimento:")
      st.write(f"1. Radice del primo termine: \(\\sqrt{{{a}}} = {sq_a:g}\).")
      st.write(f"2. Radice del terzo termine: \(\\sqrt{{{c}}} = {sq_c:g}\).")
      st.write(
          f"3. Verifica doppio prodotto: $2 \\cdot ({sq_a:g}) \\cdot ({sq_c:g})"
          f" = {2*sq_a*sq_c:g}$ (uguale a \(|{b:g}|\))."
      )
      st.success(
          f"**Risultato:** {a:g}x² + ({b:g})x + {c:g} = **({sq_a:g}x {segno}"
          f" {sq_c:g})²**"
      )

  # --- 7. Trinomio notevole (a = 1) ---
  elif opzione == "7. Trinomio notevole (a = 1)":
    st.subheader("Trinomio Notevole (a = 1) [x² + sx + p = (x + m)(x + n)]")
    s = st.number_input("Somma 's' (coefficiente della x)", value=5, step=1)
    p = st.number_input("Prodotto 'p' (termine noto)", value=6, step=1)

    if st.button("Calcola e mostra procedimento"):
      trovato = False
      for m in range(-200, 201):
        for n in range(-200, 201):
          if m + n == s and m * n == p:
            trovato = True
            segno_m = f"+ {m}" if m >= 0 else f"- {-m}"
            segno_n = f"+ {n}" if n >= 0 else f"- {-n}"
            st.write("### 📝 Procedimento:")
            st.write(
                f"Cerchiamo due numeri \(m\) e \(n\) tali che \(m + n = {s}\) e $m"
                f" \\cdot n = {p}$."
            )
            st.write(f"Trovati: **m = {m}**, **n = {n}**.")
            st.success(
                f"**Risultato:** x² + ({s})x + ({p}) = **(x {segno_m})(x"
                f" {segno_n})**"
            )
            break
        if trovato:
          break
      if not trovato:
        st.error(
            "Nessuna coppia di numeri interi trovata per questa somma e"
            " prodotto."
        )

  # --- 8. Trinomio notevole (a ≠ 1) ---
  elif opzione == "8. Trinomio notevole (a ≠ 1)":
    st.subheader("Trinomio Notevole con a ≠ 1 [ax² + sx + p]")
    a = st.number_input("Coefficiente 'a' (di x²)", value=2, step=1)
    s = st.number_input("Coefficiente 's' (di x)", value=7, step=1)
    p = st.number_input("Termine noto 'p'", value=3, step=1)

    if st.button("Calcola e mostra procedimento"):
      prod = a * p
      trovato = False
      for m in range(-200, 201):
        for n in range(-200, 201):
          if m + n == s and m * n == prod:
            trovato = True
            st.write("### 📝 Procedimento:")
            st.write(f"1. Calcoliamo \(a \\cdot p = {a} \\cdot {p} = {prod}\).")
            st.write(
                f"2. Cerchiamo due numeri con somma {s} e prodotto {prod}:"
                f" **{m}** e **{n}**."
            )
            st.write(
                f"3. Riscriviamo il trinomio: **{a}x² + ({m})x + ({n})x +"
                f" {p}**"
            )
            st.write("4. Eseguiamo il raccoglimento parziale.")
            st.success("Scomposizione pronta per il raccoglimento parziale.")
            break
        if trovato:
          break
      if not trovato:
        st.error(
            "Nessuna coppia di interi trovata per scomporre con questo metodo."
        )

  # --- 9. Cubo di binomio ---
  elif opzione == "9. Cubo di binomio":
    st.subheader("Cubo di Binomio [(a ± b)³]")
    a3 = st.number_input("Primo cubo (a³)", value=8.0)
    b3 = st.number_input("Secondo cubo (b³)", value=1.0)

    if st.button("Calcola e mostra procedimento"):
      a = (
          round(a3 ** (1 / 3), 4)
          if a3 >= 0
          else -round((-a3) ** (1 / 3), 4)
      )
      b = (
          round(b3 ** (1 / 3), 4)
          if b3 >= 0
          else -round((-b3) ** (1 / 3), 4)
      )
      segno = "+" if b >= 0 else "-"
      st.write("### 📝 Procedimento:")
      st.write(
          f"1. Radice cubica del primo termine: \(\\sqrt[3]{{{a3}}} = {a:g}\)."
      )
      st.write(
          f"2. Radice cubica del secondo termine: \(\\sqrt[3]{{{b3}}} = {b:g}\)."
      )
      st.success(f"**Risultato:** **({a:g}x {segno} {abs(b):g})³**")

  # --- 10. Quadrato di un trinomio ---
  elif opzione == "10. Quadrato di un trinomio":
    st.subheader(
        "Quadrato di un Trinomio [(a + b + c)² = a² + b² + c² + 2ab + 2ac +"
        " 2bc]"
    )
    a2 = st.number_input("Primo quadrato (a²)", value=4.0, min_value=0.0)
    b2 = st.number_input("Secondo quadrato (b²)", value=9.0, min_value=0.0)
    c2 = st.number_input("Terzo quadrato (c²)", value=16.0, min_value=0.0)

    if st.button("Calcola e mostra procedimento"):
      a = math.sqrt(a2)
      b = math.sqrt(b2)
      c = math.sqrt(c2)
      st.write("### 📝 Procedimento:")
      st.write(
          f"Estraiamo la radice quadrata dei tre termini: $a={a:g}, b={b:g},"
          f" c={c:g}$."
      )
      st.success(f"**Risultato:** **({a:g}x + {b:g}y + {c:g}z)²**")

  # --- 11. Cubo di un trinomio ---
  elif opzione == "11. Cubo di un trinomio":
    st.subheader("Cubo di un Trinomio [(a + b + c)³]")
    a3 = st.number_input("Primo cubo (a³)", value=1.0)
    b3 = st.number_input("Secondo cubo (b³)", value=8.0)
    c3 = st.number_input("Terzo cubo (c³)", value=27.0)

    if st.button("Calcola e mostra procedimento"):
      a = (
          round(a3 ** (1 / 3), 4)
          if a3 >= 0
          else -round((-a3) ** (1 / 3), 4)
      )
      b = (
          round(b3 ** (1 / 3), 4)
          if b3 >= 0
          else -round((-b3) ** (1 / 3), 4)
      )
      c = (
          round(c3 ** (1 / 3), 4)
          if c3 >= 0
          else -round((-c3) ** (1 / 3), 4)
      )
      st.write("### 📝 Procedimento:")
      st.write(
          f"Estraiamo la radice cubica dei tre termini: $a={a:g}, b={b:g},"
          f" c={c:g}$."
      )
      st.success(f"**Risultato:** **({a:g} + {b:g} + {c:g})³**")


# ==========================================================
# 2. SISTEMI LINEARI
# ==========================================================
elif categoria == "Sistemi Lineari":
  st.header("📐 Risoluzione Sistemi Lineari")

  metodo = st.selectbox(
      "Scegli il Metodo di Risoluzione:",
      [
          "1. Metodo di Sostituzione",
          "2. Metodo di Addizione e Sottrazione (Riduzione)",
          "3. Metodo Grafico",
      ],
  )

  st.write(
      "Inserisci le equazioni come nel libro di testo (es: `4*x + 2*y = 1`"
      " oppure `x + 2*(y - 1) = 6`):"
  )

  eq1_input = st.text_input("Prima Equazione", value="4*x + 2*y = 1")
  eq2_input = st.text_input("Seconda Equazione", value="2*x - y = -1")

  # Mostra il sistema con la graffa iniziale
  st.write("### Sistema Iniziale:")
  disp_eq1 = eq1_input.replace("*", "").replace("=", " = ")
  disp_eq2 = eq2_input.replace("*", "").replace("=", " = ")
  st.latex(r"\begin{cases} " + disp_eq1 + r" \\ " + disp_eq2 + r" \end{cases}")

  if st.button("Risolvi con passaggi del quaderno"):
    try:
      x, y = sp.symbols("x y")

      # Parse equazioni e le porta nella forma f(x,y) = 0
      lhs1, rhs1 = eq1_input.split("=")
      lhs2, rhs2 = eq2_input.split("=")

      e1 = sp.expand(sp.sympify(lhs1) - sp.sympify(rhs1))
      e2 = sp.expand(sp.sympify(lhs2) - sp.sympify(rhs2))

      # Estrazione dei coefficienti ax + by = c
      a1 = e1.coeff(x)
      b1 = e1.coeff(y)
      c1 = -e1.subs({x: 0, y: 0})

      a2 = e2.coeff(x)
      b2 = e2.coeff(y)
      c2 = -e2.subs({x: 0, y: 0})

      det = a1 * b2 - a2 * b1

      if det == 0:
        st.error("Il sistema è impossibile o indeterminato (D = 0).")
      else:
        x_sol = sp.Rational(c1 * b2 - c2 * b1, det)
        y_sol = sp.Rational(a1 * c2 - a2 * c1, det)

        st.write("### 📝 Svolgimento passo-passo:")

        # ------------------------------------------------------
        # METODO 1: SOSTITUZIONE
        # ------------------------------------------------------
        if "Sostituzione" in metodo:
          st.write(
              "**1. Portiamo le equazioni in forma normale \(ax + by = c\):**"
          )
          st.latex(
              r"\begin{cases} "
              + f"{a1}x + {b1}y = {c1}"
              + r" \\ "
              + f"{a2}x + {b2}y = {c2}"
              + r" \end{cases}"
          )

          y_expr = sp.simplify((c2 - a2 * x) / b2)

          st.write("**2. Isoliamo \(y\) dalla seconda equazione:**")
          st.latex(
              r"\begin{cases} "
              + f"{a1}x + {b1}y = {c1}"
              + r" \\ "
              + f"y = {sp.latex(y_expr)}"
              + r" \end{cases}"
          )

          st.write(
              "**3. Sostituiamo l'espressione di \(y\) nella prima equazione:**"
          )
          st.latex(
              r"\begin{cases} "
              + f"{a1}x + {b1}\\cdot\\left({sp.latex(y_expr)}\\right) = {c1}"
              + r" \\ '' \end{cases}"
          )

          st.write("**4. Ricaviamo il valore di \(x\):**")
          st.latex(
              r"\begin{cases} x = "
              + sp.latex(x_sol)
              + r" \\ '' \end{cases}"
          )

          st.write("**5. Sostituiamo \(x\) nell'equazione di \(y\):**")
          st.latex(
              r"\begin{cases} '' \\ y = "
              + sp.latex(y_expr.subs(x, x_sol))
              + r" \end{cases} \Rightarrow \begin{cases} x = "
              + sp.latex(x_sol)
              + r" \\ y = "
              + sp.latex(y_sol)
              + r" \end{cases}"
          )

        # ------------------------------------------------------
        # METODO 2: ADDIZIONE E SOTTRAZIONE (RIDUZIONE)
        # ------------------------------------------------------
        elif "Addizione" in metodo:
          st.write(
              "**1. Eliminiamo \(y\) per somma/differenza tra le due"
              " equazioni:**"
          )
          st.latex(
              r"\begin{array}{r} "
              + f"{a1*b2}x + {b1*b2}y = {c1*b2}"
              + r" \\ + \quad "
              + f"{-a2*b1}x - {b1*b2}y = {-c2*b1}"
              + r" \\ \hline "
              + f"{(a1*b2 - a2*b1)}x + 0y = {(c1*b2 - c2*b1)}"
              + r" \end{array}"
          )
          st.latex(r"x = " + sp.latex(x_sol))

          st.write(
              "**2. Eliminiamo \(x\) per somma/differenza tra le due"
              " equazioni:**"
          )
          st.latex(
              r"\begin{array}{r} "
              + f"{a1*a2}x + {b1*a2}y = {c1*a2}"
              + r" \\ - \quad "
              + f"{a1*a2}x + {a1*b2}y = {a1*c2}"
              + r" \\ \hline "
              + f"0x + {(b1*a2 - a1*b2)}y = {(c1*a2 - a1*c2)}"
              + r" \end{array}"
          )
          st.latex(r"y = " + sp.latex(y_sol))

        # ------------------------------------------------------
        # METODO 3: GRAFICO
        # ------------------------------------------------------
        elif "Grafico" in metodo:
          st.write("**1. Esplicitiamo la \(y\) per entrambe le rette:**")
          y1_eq = sp.simplify((c1 - a1 * x) / b1)
          y2_eq = sp.simplify((c2 - a2 * x) / b2)
          st.latex(r"r: y = " + sp.latex(y1_eq))
          st.latex(r"s: y = " + sp.latex(y2_eq))

          st.write("**2. Tabelle dei punti con i passaggi:**")

          def pulisci_testo(expr_str):
            return str(expr_str).replace("*", "·").replace(" ", "")

          y1_calc_0 = pulisci_testo(y1_eq.subs(x, 0))
          y1_calc_1 = pulisci_testo(y1_eq.subs(x, 1))
          header_1 = pulisci_testo(y1_eq)

          expr1_str = str(y1_eq)
          step1_0 = expr1_str.replace("x", "·0")
          step1_1 = expr1_str.replace("x", "·1")

          df_r1 = {
              "x": [0, 1],
              header_1: [
                  f"{pulisci_testo(step1_0)} = {y1_calc_0}",
                  f"{pulisci_testo(step1_1)} = {y1_calc_1}",
              ],
          }

          y2_calc_0 = pulisci_testo(y2_eq.subs(x, 0))
          y2_calc_1 = pulisci_testo(y2_eq.subs(x, 1))
          header_2 = pulisci_testo(y2_eq)

          expr2_str = str(y2_eq)
          step2_0 = expr2_str.replace("x", "·0")
          step2_1 = expr2_str.replace("x", "·1")

          df_r2 = {
              "x": [0, 1],
              header_2: [
                  f"{pulisci_testo(step2_0)} = {y2_calc_0}",
                  f"{pulisci_testo(step2_1)} = {y2_calc_1}",
              ],
          }

          col_t1, col_t2 = st.columns(2)
          with col_t1:
            st.write("**Retta \(r\)**")
            st.write(f"\(R_1 = (0; {y1_calc_0})\)")
            st.write(f"\(R_2 = (1; {y1_calc_1})\)")
            st.table(df_r1)

          with col_t2:
            st.write("**Retta \(s\)**")
            st.write(f"\(S_1 = (0; {y2_calc_0})\)")
            st.write(f"\(S_2 = (1; {y2_calc_1})\)")
            st.table(df_r2)

          st.write("**3. Rappresentazione sul piano cartesiano:**")
          px, py = float(x_sol), float(y_sol)
          x_vals = np.linspace(px - 3, px + 3, 400)
          y1_vals = [float(y1_eq.subs(x, val)) for val in x_vals]
          y2_vals = [float(y2_eq.subs(x, val)) for val in x_vals]

          fig, ax = plt.subplots(figsize=(6, 5))
          ax.plot(x_vals, y1_vals, label="r", color="purple")
          ax.plot(x_vals, y2_vals, label="s", color="black")

          ax.plot(px, py, "ro", label=f"S({x_sol}, {y_sol})")
          ax.vlines(
              px, ymin=min(y1_vals), ymax=py, color="blue", linestyle="--"
          )
          ax.hlines(
              py, xmin=min(x_vals), xmax=px, color="blue", linestyle="--"
          )

          ax.axhline(0, color="black", linewidth=1)
          ax.axvline(0, color="black", linewidth=1)
          ax.grid(True, linestyle=":")
          ax.legend()
          st.pyplot(fig)

          st.success(
              f"**Soluzione finale del sistema:** S = ({x_sol} ; {y_sol})"
          )

    except Exception as err:
      st.error(f"Si è verificato un errore: {err}")