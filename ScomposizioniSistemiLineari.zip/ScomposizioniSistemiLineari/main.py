import math
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput


class MathApp(App):

  def build(self):
    # Layout principale verticale
    self.layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

    # Titolo
    self.title_label = Label(
        text='Raccoglimento Totale',
        font_size='22sp',
        bold=True,
        size_hint_y=None,
        height=40,
    )
    self.layout.add_widget(self.title_label)

    # Input Primo Coefficiente
    self.input_a = TextInput(
        hint_text='Primo coefficiente (es. 6)',
        input_filter='int',
        multiline=False,
        size_hint_y=None,
        height=50,
    )
    self.layout.add_widget(self.input_a)

    # Input Secondo Coefficiente
    self.input_b = TextInput(
        hint_text='Secondo coefficiente (es. 9)',
        input_filter='int',
        multiline=False,
        size_hint_y=None,
        height=50,
    )
    self.layout.add_widget(self.input_b)

    # Pulsante Calcola
    self.btn_calcola = Button(
        text='Calcola Scomposizione',
        size_hint_y=None,
        height=60,
        background_color=(0.2, 0.6, 1, 1),
    )
    self.btn_calcola.bind(on_press=self.calcola_mcd)
    self.layout.add_widget(self.btn_calcola)

    # Etichetta Risultato
    self.result_label = Label(
        text='', font_size='16sp', size_hint_y=None, height=150
    )
    self.layout.add_widget(self.result_label)

    return self.layout

  def calcola_mcd(self, instance):
    try:
      a = int(self.input_a.text)
      b = int(self.input_b.text)

      mcd = math.gcd(a, b)
      r1 = a // mcd
      r2 = b // mcd

      testo = (
          f'Procedimento:\n'
          f'1. MCD tra {a} e {b} = {mcd}\n'
          f'2. Divido: {a}/{mcd} = {r1}, {b}/{mcd} = {r2}\n\n'
          f'Risultato: {mcd}({r1}x + {r2}y)'
      )
      self.result_label.text = testo
    except ValueError:
      self.result_label.text = 'Inserisci numeri interi validi!'


if __name__ == '__main__':
  MathApp().run()