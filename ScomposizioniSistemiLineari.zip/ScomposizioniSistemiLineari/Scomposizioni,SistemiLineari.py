import math
import matplotlib.pyplot as plt
import numpy as np


def raccoglimento_totale():
  a = int(input("Inserisci il primo coefficiente (es. 6 per 6x): "))
  b = int(input("Inserisci il secondo coefficiente (es. 9 per 9y): "))
  mcd = math.gcd(a, b)
  print(f"\nRisultato: {a}x + {b}y = {mcd}({a//mcd}x + {b//mcd}y)")


def raccoglimento_parziale():
  a = input("Inserisci il primo termine comune (es. a): ")
  b = input("Inserisci il secondo termine comune (es. b): ")
  x = input("Inserisci la variabile x: ")
  y = input("Inserisci la variabile y: ")
  print(
      f"\nProcedimento: {a}({x} + {y}) + {b}({x} + {y}) = ({a} + {b})({x} + {y})"
  )


def diff_quadrati():
  a2 = float(input("Inserisci a² (es. 16 per 16x²): "))
  b2 = float(input("Inserisci b² (es. 9): "))
  a = math.sqrt(a2)
  b = math.sqrt(b2)
  print(f"\nRisultato: ({a}x - {b})({a}x + {b})")


def diff_cubi():
  a3 = float(input("Inserisci a³ (es. 27 per 27x³): "))
  b3 = float(input("Inserisci b³ (es. 8): "))
  a = round(a3 ** (1 / 3), 4)
  b = round(b3 ** (1 / 3), 4)
  print(f"\nRisultato: ({a}x - {b})({a**2}x² + {a*b}x + {b**2})")


def somma_cubi():
  a3 = float(input("Inserisci a³ (es. 27 per 27x³): "))
  b3 = float(input("Inserisci b³ (es. 8): "))
  a = round(a3 ** (1 / 3), 4)
  b = round(b3 ** (1 / 3), 4)  # CORRETTO: in precedenza calcolava a3**(1/3)
  print(f"\nRisultato: ({a}x + {b})({a**2}x² - {a*b}x + {b**2})")


def quadrato_binomio():
  a2 = float(input("Inserisci il primo termine a² (es. 4 per 4x²): "))
  ab2 = float(input("Inserisci il doppio prodotto (può essere - o +): "))
  b2 = float(input("Inserisci il termine b² (es. 9): "))
  a = math.sqrt(a2)
  b = math.sqrt(b2)
  segno = "+" if ab2 >= 0 else "-"
  print(f"\nRisultato: ({a}x {segno} {b})²")


def trinomio_a1():
  s = int(input("Inserisci la somma (s): "))
  p = int(input("Inserisci il prodotto (p): "))
  for m in range(-200, 201):
    for n in range(-200, 201):
      if m + n == s and m * n == p:
        print(f"\nRisultato: (x + {m})(x + {n})")
        return
  print("\nCoppia non trovata.")


def trinomio_a_diverso_1():
  a = int(input("Inserisci a: "))
  s = int(input("Inserisci s: "))
  p = int(input("Inserisci p: "))
  prod = a * p
  for m in range(-200, 201):
    for n in range(-200, 201):
      if m + n == s and m * n == prod:
        print(f"\nScomponi il termine centrale: {a}x² + ({m})x + ({n})x + {p}")
        return
  print("\nCoppia non trovata.")


def cubo_binomio():
  a3 = float(input("Inserisci a³: "))
  b3 = float(input("Inserisci b³: "))
  a = round(a3 ** (1 / 3), 4) if a3 >= 0 else -round((-a3) ** (1 / 3), 4)
  b = round(b3 ** (1 / 3), 4) if b3 >= 0 else -round((-b3) ** (1 / 3), 4)
  segno = "+" if b >= 0 else "-"
  print(f"\nRisultato: ({a}x {segno} {abs(b)})³")


def quadrato_trinomio():
  a2 = float(input("Inserisci a²: "))
  b2 = float(input("Inserisci b²: "))
  c2 = float(input("Inserisci c²: "))
  a = math.sqrt(a2)
  b = math.sqrt(b2)
  c = math.sqrt(c2)
  print(f"\nRisultato: ({a}x + {b}y + {c}z)²")


def cubo_trinomio():
  a3 = float(input("Inserisci a³: "))
  b3 = float(input("Inserisci b³: "))
  c3 = float(input("Inserisci c³: "))
  a = round(a3 ** (1 / 3), 4) if a3 >= 0 else -round((-a3) ** (1 / 3), 4)
  b = round(b3 ** (1 / 3), 4) if b3 >= 0 else -round((-b3) ** (1 / 3), 4)
  c = round(c3 ** (1 / 3), 4) if c3 >= 0 else -round((-c3) ** (1 / 3), 4)
  print(f"\nRisultato: ({a} + {b} + {c})³")


# --- SISTEMI LINEARI CLI ---
def risolvi_sistema(a1, b1, c1, a2, b2, c2, metodo):
  det = a1 * b2 - a2 * b1
  if det == 0:
    print("\nIl sistema è impossibile o indeterminato.")
    return

  x = (c1 * b2 - c2 * b1) / det
  y = (a1 * c2 - a2 * c1) / det

  if metodo == 1:
    print("\n--- Metodo di Sostituzione ---")
    print(f"y = ({c2} - {a2}x) / {b2}")
    print(f"Sostituendo x: x = {x:.2f}, y = {y:.2f}")

  elif metodo == 2:
    print("\n--- Metodo di Riduzione ---")
    print(f"x = {x:.2f}, y = {y:.2f}")

  elif metodo == 3:
    print("\n--- Metodo Grafico ---")
    x_vals = np.linspace(x - 5, x + 5, 100)
    y1_vals = (c1 - a1 * x_vals) / b1
    y2_vals = (c2 - a2 * x_vals) / b2

    plt.figure(figsize=(6, 4))
    plt.plot(x_vals, y1_vals, label="Prima equazione")
    plt.plot(x_vals, y2_vals, label="Seconda equazione")
    plt.plot(x, y, "ro", label=f"Soluzione ({x:.2f}, {y:.2f})")
    plt.axhline(0, color="black", lw=0.5)
    plt.axvline(0, color="black", lw=0.5)
    plt.legend()
    plt.grid(True)
    plt.show()


def menu():
  print("\n1. Scomposizioni")
  print("2. Sistemi Lineari")
  scelta = input("Seleziona opzione: ")

  if scelta == "1":
    print("\nScegli scomposizione:")
    print("1. Raccoglimento totale")
    print("2. Raccoglimento parziale")
    print("3. Differenza di due quadrati")
    print("4. Differenza di cubi")
    print("5. Somma di cubi")
    print("6. Quadrato di binomio")
    print("7. Trinomio notevole (a = 1)")
    print("8. Trinomio notevole (a != 1)")
    print("9. Cubo di binomio")
    print("10. Quadrato di trinomio")
    print("11. Cubo di trinomio")
    sub = input("Scelta: ")

    funzioni = {
        "1": raccoglimento_totale,
        "2": raccoglimento_parziale,
        "3": diff_quadrati,
        "4": diff_cubi,
        "5": somma_cubi,
        "6": quadrato_binomio,
        "7": trinomio_a1,
        "8": trinomio_a_diverso_1,
        "9": cubo_binomio,
        "10": quadrato_trinomio,
        "11": cubo_trinomio,
    }
    if sub in funzioni:
      funzioni[sub]()

  elif scelta == "2":
    a1 = float(input("a1: "))
    b1 = float(input("b1: "))
    c1 = float(input("c1: "))
    a2 = float(input("a2: "))
    b2 = float(input("b2: "))
    c2 = float(input("c2: "))
    m = int(input("Metodo (1=Sostituzione, 2=Riduzione, 3=Grafico): "))
    risolvi_sistema(a1, b1, c1, a2, b2, c2, m)


if __name__ == "__main__":
  menu()

# ==========================================================
# 2. FUNZIONI PER I SISTEMI LINEARI
# ==========================================================

def input_sistema():
    print("\nInserisci i coefficienti del sistema nella forma:")
    print(" 1) a1*x + b1*y = c1")
    print(" 2) a2*x + b2*y = c2")
    try:
        a1 = float(input("a1 = "))
        b1 = float(input("b1 = "))
        c1 = float(input("c1 = "))
        a2 = float(input("a2 = "))
        b2 = float(input("b2 = "))
        c2 = float(input("c2 = "))
        return a1, b1, c1, a2, b2, c2
    except ValueError:
        print("Errore: Inserisci valori numerici validi.")
        return None

def sistema_sostituzione():
    print("\n--- SISTEMA LINEARE: METODO DI SOSTITUZIONE ---")
    dati = input_sistema()
    if not dati: return
    a1, b1, c1, a2, b2, c2 = dati

    det = a1 * b2 - a2 * b1
    if det == 0:
        print("\nIl sistema è impossibile o indeterminato (determinante = 0).")
        return

    print(f"\nPasso 1: Isolo x dalla prima equazione -> x = ({c1} - ({b1})y) / {a1}")
    y = (c2 * a1 - a2 * c1) / det
    x = (c1 - b1 * y) / a1
    print(f"Passo 2: Sostituisco x nella seconda equazione e trovo y = {y:g}")
    print(f"Passo 3: Sostituisco y per calcolare x = {x:g}")
    print(f"\n👉 SOLUZIONE: x = {x:g}, y = {y:g}")

def sistema_addizione_sottrazione():
    print("\n--- SISTEMA LINEARE: METODO DI ADDIZIONE E SOTTRAZIONE ---")
    dati = input_sistema()
    if not dati: return
    a1, b1, c1, a2, b2, c2 = dati

    det = a1 * b2 - a2 * b1
    if det == 0:
        print("\nIl sistema è impossibile o indeterminato.")
        return

    print(f"\nPasso 1: Moltiplico l'Eq.(1) per {a2} e l'Eq.(2) per {a1} per azzerare la x.")
    y = (c1 * a2 - c2 * a1) / (b1 * a2 - b2 * a1)
    print(f"Sottraendo le due equazioni otteniamo: y = {y:g}")

    print(f"Passo 2: Moltiplico l'Eq.(1) per {b2} e l'Eq.(2) per {b1} per azzerare la y.")
    x = (c1 * b2 - c2 * b1) / det
    print(f"Sottraendo le due equazioni otteniamo: x = {x:g}")

    print(f"\n👉 SOLUZIONE: x = {x:g}, y = {y:g}")

def sistema_grafico():
    print("\n--- SISTEMA LINEARE: METODO GRAFICO ---")
    dati = input_sistema()
    if not dati: return
    a1, b1, c1, a2, b2, c2 = dati

    if b1 == 0 or b2 == 0:
        print("Per il metodo grafico, i coefficienti b1 e b2 devono essere diversi da zero.")
        return

    det = a1 * b2 - a2 * b1
    if det == 0:
        print("Le due rette sono parallele: il sistema è impossibile o indeterminato.")
        return

    x_sol = (c1 * b2 - c2 * b1) / det
    y_sol = (a1 * c2 - a2 * c1) / det

    print(f"\nRetta 1: y = ({c1} - {a1}x) / {b1}")
    print(f"Retta 2: y = ({c2} - {a2}x) / {b2}")
    print(f"👉 Punto di intersezione: P({x_sol:g}, {y_sol:g})")

    # Generazione grafico
    x_vals = np.linspace(x_sol - 10, x_sol + 10, 400)
    y1_vals = (c1 - a1 * x_vals) / b1
    y2_vals = (c2 - a2 * x_vals) / b2

    plt.figure(figsize=(8, 6))
    plt.plot(x_vals, y1_vals, label=f'{a1}x + {b1}y = {c1}', color='blue')
    plt.plot(x_vals, y2_vals, label=f'{a2}x + {b2}y = {c2}', color='green')
    plt.plot(x_sol, y_sol, 'ro', label=f'Intersezione ({x_sol:.2f}, {y_sol:.2f})')

    plt.axhline(0, color='black', linewidth=0.8)
    plt.axvline(0, color='black', linewidth=0.8)
    plt.grid(True, linestyle='--')
    plt.legend()
    plt.title("Metodo Grafico - Intersezione di Rette")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.show()


# ==========================================================
# 3. MENU PRINCIPALE (APP)
# ==========================================================

def menu_scomposizioni():
    while True:
        print("\n" + "="*45)
        print("      MENU SCOMPOSIZIONI")
        print("="*45)
        print("1. Raccoglimento totale")
        print("2. Raccoglimento parziale")
        print("3. Differenza di due quadrati")
        print("4. Differenza di cubi")
        print("5. Somma di cubi")
        print("6. Quadrato di binomio")
        print("7. Trinomio notevole (a = 1)")
        print("8. Trinomio notevole (a ≠ 1)")
        print("9. Cubo di binomio")
        print("10. Quadrato di un trinomio")
        print("11. Cubo di un trinomio")
        print("0. Torna al menu principale")
        
        scelta = input("\nSeleziona un'opzione (0-11): ").strip()
        
        if scelta == '1': raccoglimento_totale()
        elif scelta == '2': raccoglimento_parziale()
        elif scelta == '3': differenza_quadrati()
        elif scelta == '4': differenza_cubi()
        elif scelta == '5': somma_cubi()
        elif scelta == '6': quadrato_binomio()
        elif scelta == '7': trinomio_a1()
        elif scelta == '8': trinomio_a_diverso_1()
        elif scelta == '9': cubo_binomio()
        elif scelta == '10': quadrato_trinomio()
        elif scelta == '11': cubo_trinomio()
        elif scelta == '0': break
        else: print("Opzione non valida, riprova.")

def menu_sistemi():
    while True:
        print("\n" + "="*45)
        print("      MENU SISTEMI LINEARI")
        print("="*45)
        print("1. Metodo di Sostituzione")
        print("2. Metodo di Addizione e Sottrazione")
        print("3. Metodo Grafico")
        print("0. Torna al menu principale")
        
        scelta = input("\nSeleziona un'opzione (0-3): ").strip()
        
        if scelta == '1': sistema_sostituzione()
        elif scelta == '2': sistema_addizione_sottrazione()
        elif scelta == '3': sistema_grafico()
        elif scelta == '0': break
        else: print("Opzione non valida, riprova.")

def app():
    while True:
        print("\n" + "#"*45)
        print("   CALCOLATORE DI MATEMATICA INTERATTIVO")
        print("#"*45)
        print("1. Scomposizioni")
        print("2. Sistemi Lineari")
        print("0. Esci dall'applicazione")
        
        scelta = input("\nScegli la categoria desiderata (0-2): ").strip()
        
        if scelta == '1': menu_scomposizioni()
        elif scelta == '2': menu_sistemi()
        elif scelta == '0':
            print("\nGrazie per aver usato l'applicazione. Arrivederci!")
            break
        else:
            print("Scelta non valida. Riprova.")

if __name__ == "__main__":
    app()